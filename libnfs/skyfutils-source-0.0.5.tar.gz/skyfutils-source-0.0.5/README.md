# SkyFUtils 通用模块集合

## 安装
* `cnpm install @qnpm/skyfutils --save`
* `cnpm install @qnpm/skyfutils --save-dev`
* 或者使用`npm`进行安装

## 使用文档
* http://10.16.66.9:5025/page/
* http://10.16.66.42:5025/page/